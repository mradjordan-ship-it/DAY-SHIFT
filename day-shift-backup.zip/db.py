"""Database connection and schema management for Day Shift marketplace."""
import os
from contextlib import contextmanager
import psycopg2
from psycopg2.extras import RealDictCursor

DATABASE_URL = os.environ.get("DAYSHI_URL", "")


def get_conn():
    if not DATABASE_URL:
        raise RuntimeError("NEON_DATABASE_URL environment variable not set")
    return psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor)


@contextmanager
def db_conn():
    """Context manager that guarantees connection cleanup on success or error."""
    conn = get_conn()
    cur = conn.cursor()
    try:
        yield conn, cur
    except Exception:
        conn.rollback()
        raise
    finally:
        cur.close()
        conn.close()


def init_db():
    """Create all tables if they don't exist."""
    conn = get_conn()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'worker',  -- 'worker' | 'employer'
            bio TEXT DEFAULT '',
            avatar_url TEXT DEFAULT '',
            avg_rating NUMERIC(3,2) DEFAULT 0,
            total_shifts INTEGER DEFAULT 0,
            reset_token TEXT,
            reset_token_expires TIMESTAMPTZ,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Safe column additions if table already exists
        ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token TEXT;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS reset_token_expires TIMESTAMPTZ;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS is_advertiser BOOLEAN DEFAULT FALSE;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS advertiser_agreement_accepted BOOLEAN DEFAULT FALSE;
        ALTER TABLE users ADD COLUMN IF NOT EXISTS onboarded BOOLEAN DEFAULT FALSE;
        ALTER TABLE videos ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'general';
        ALTER TABLE videos ADD COLUMN IF NOT EXISTS price TEXT DEFAULT '';
        ALTER TABLE videos ADD COLUMN IF NOT EXISTS event_date TEXT DEFAULT '';
        ALTER TABLE videos ADD COLUMN IF NOT EXISTS event_time TEXT DEFAULT '';
        ALTER TABLE videos ADD COLUMN IF NOT EXISTS scheduled_at TIMESTAMPTZ DEFAULT NULL;

        CREATE TABLE IF NOT EXISTS videos (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            video_url TEXT,
            image_url TEXT,
            thumbnail_url TEXT DEFAULT '',
            type TEXT NOT NULL,  -- 'worker' | 'employer'
            post_type TEXT DEFAULT 'video',  -- 'video' | 'image' | 'text'
            category TEXT DEFAULT 'general',  -- 'general' | 'sale' | 'event'
            price TEXT DEFAULT '',
            event_date TEXT DEFAULT '',
            event_time TEXT DEFAULT '',
            aspect_ratio TEXT DEFAULT '9:16',  -- '9:16' | '1:1' | '4:5' | '16:9'
            title TEXT,
            description TEXT DEFAULT '',
            cuisine_type TEXT DEFAULT '',
            pay_rate TEXT DEFAULT '',
            hours TEXT DEFAULT '',
            experience_level TEXT DEFAULT '',
            location TEXT DEFAULT '',
            likes INTEGER DEFAULT 0,
            scheduled_at TIMESTAMPTZ DEFAULT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS likes (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            video_id INTEGER REFERENCES videos(id) ON DELETE CASCADE,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(user_id, video_id)
        );

        CREATE TABLE IF NOT EXISTS matches (
            id SERIAL PRIMARY KEY,
            worker_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            employer_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            worker_video_id INTEGER REFERENCES videos(id),
            employer_video_id INTEGER REFERENCES videos(id),
            status TEXT DEFAULT 'pending',  -- 'pending' | 'active' | 'completed' | 'cancelled'
            initiated_by INTEGER REFERENCES users(id),
            worker_confirmed BOOLEAN DEFAULT FALSE,
            employer_confirmed BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS messages (
            id SERIAL PRIMARY KEY,
            match_id INTEGER REFERENCES matches(id) ON DELETE CASCADE,
            sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            content TEXT NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS reviews (
            id SERIAL PRIMARY KEY,
            match_id INTEGER REFERENCES matches(id) ON DELETE CASCADE,
            reviewer_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            reviewee_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            rating INTEGER CHECK(rating >= 1 AND rating <= 5),
            feedback TEXT DEFAULT '',
            created_at TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(match_id, reviewer_id)
        );

        CREATE TABLE IF NOT EXISTS support_threads (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            subject TEXT DEFAULT '',
            status TEXT DEFAULT 'open',  -- 'open' | 'closed'
            source TEXT DEFAULT 'app',   -- 'app' | 'sponsor'
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS support_messages (
            id SERIAL PRIMARY KEY,
            thread_id INTEGER REFERENCES support_threads(id) ON DELETE CASCADE,
            sender_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            sender_role TEXT DEFAULT 'user',  -- 'user' | 'admin' | 'auto'
            content TEXT NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS sponsor_contacts (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            organization TEXT DEFAULT '',
            type TEXT DEFAULT 'sponsor',  -- 'sponsor' | 'donor' | 'supporter' | 'other'
            message TEXT DEFAULT '',
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS sponsor_replies (
            id SERIAL PRIMARY KEY,
            contact_id INTEGER REFERENCES sponsor_contacts(id) ON DELETE CASCADE,
            admin_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            content TEXT NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Tips / donations
        CREATE TABLE IF NOT EXISTS tips (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
            amount INTEGER NOT NULL,  -- in cents ($1 = 100)
            name TEXT DEFAULT '',
            email TEXT DEFAULT '',
            message TEXT DEFAULT '',
            status TEXT DEFAULT 'pending',  -- 'pending' | 'completed' | 'refunded'
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        -- Bookmarks / saved posts
        CREATE TABLE IF NOT EXISTS bookmarks (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            video_id INTEGER REFERENCES videos(id) ON DELETE CASCADE,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(user_id, video_id)
        );

        -- User blocks
        CREATE TABLE IF NOT EXISTS user_blocks (
            id SERIAL PRIMARY KEY,
            blocker_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            blocked_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(blocker_id, blocked_id)
        );
    """)

    conn.commit()
    cur.close()
    conn.close()
