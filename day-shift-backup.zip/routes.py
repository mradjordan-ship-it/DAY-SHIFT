"""Day Shift Marketplace — FastAPI routes."""
import os
import uuid
import shutil
import asyncio
import aiofiles
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, FastAPI, Request, HTTPException, Depends, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import bcrypt as _bcrypt
from jose import jwt, JWTError
import imageio_ffmpeg

from db import get_conn, init_db, db_conn

# ── Auth Setup ────────────────────────────────────────────────────────────────
SECRET_KEY = os.environ.get("SECRET_KEY")
if not SECRET_KEY:
    raise RuntimeError("SECRET_KEY environment variable is required. Set it before starting the server.")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

MAX_IMAGE_BYTES = 10 * 1024 * 1024   # 10 MB
MAX_VIDEO_BYTES = 100 * 1024 * 1024  # 100 MB

bearer = HTTPBearer(auto_error=False)

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

FFMPEG_BIN = imageio_ffmpeg.get_ffmpeg_exe()


async def transcode_video(src: Path, dest: Path) -> bool:
    """Transcode to H.264 MP4 with faststart. Preserves original resolution — no downscaling."""
    cmd = [
        FFMPEG_BIN, "-y", "-i", str(src),
        "-c:v", "libx264",
        "-crf", "18",
        "-preset", "slow",
        "-c:a", "aac",
        "-b:a", "192k",
        "-movflags", "+faststart",
        "-pix_fmt", "yuv420p",
        str(dest),
    ]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=300)
        if proc.returncode != 0:
            print(f"[FFmpeg] error: {stderr.decode()[-500:]}")
            return False
        return True
    except Exception as e:
        print(f"[FFmpeg] exception: {e}")
        return False


def hash_password(password: str) -> str:
    return _bcrypt.hashpw(password.encode("utf-8")[:72], _bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    return _bcrypt.checkpw(plain.encode("utf-8")[:72], hashed.encode())


def create_token(user_id: int) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode({"sub": str(user_id), "exp": expire}, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer)):
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = int(payload["sub"])
    except (JWTError, KeyError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid token")

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cur.fetchone()
    cur.close()
    conn.close()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    if user["is_suspended"]:
        raise HTTPException(status_code=403, detail=f"Account suspended: {user['suspension_reason'] or 'Violation of community guidelines'}")
    return dict(user)


def get_optional_user(credentials: HTTPAuthorizationCredentials = Depends(bearer)):
    if not credentials:
        return None
    try:
        return get_current_user(credentials)
    except HTTPException:
        return None


def require_admin(current_user=Depends(get_current_user)):
    if not current_user.get("is_admin"):
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user


# ── Pydantic Models ────────────────────────────────────────────────────────────
class RegisterBody(BaseModel):
    name: str
    email: str
    password: str
    role: str = "worker"


class LoginBody(BaseModel):
    email: str
    password: str


class MatchBody(BaseModel):
    worker_video_id: Optional[int] = None
    employer_video_id: Optional[int] = None


class MessageBody(BaseModel):
    content: str


class ReviewBody(BaseModel):
    rating: int
    feedback: str = ""


class ProfileUpdateBody(BaseModel):
    name: Optional[str] = None
    bio: Optional[str] = None
    email: Optional[str] = None


class ForgotPasswordBody(BaseModel):
    email: str


class ResetPasswordBody(BaseModel):
    token: str
    new_password: str


# ── Router ────────────────────────────────────────────────────────────────────
api = APIRouter()


@api.get("/health")
def health():
    return {"ok": True}


# ── Auth ──────────────────────────────────────────────────────────────────────
@api.post("/auth/register")
async def register(
    name: str = Form(...),
    email: str = Form(...),
    password: str = Form(...),
    role: str = Form("worker"),
    image: UploadFile = File(...),
    terms_accepted: str = Form(...),
    privacy_accepted: str = Form(...),
    marketing_opt_in: str = Form(...),
):
    if role not in ("worker", "employer"):
        raise HTTPException(400, "role must be 'crew' or 'spot'")
    if not image or not image.filename:
        raise HTTPException(400, "Profile image is required")

    # Parse booleans from form
    def to_bool(v: str) -> bool:
        return str(v).lower() in ("true", "1", "yes", "on")

    if not (to_bool(terms_accepted) and to_bool(privacy_accepted)):
        raise HTTPException(400, "You must accept Terms of Use and Privacy Policy.")

    # Save image first
    ext = Path(image.filename).suffix.lower() or ".jpg"
    if ext not in (".jpg", ".jpeg", ".png", ".gif", ".webp"):
        raise HTTPException(400, "Image must be jpg, png, gif, or webp")
    filename = f"avatar_{uuid.uuid4()}{ext}"
    dest = UPLOAD_DIR / filename
    content = await image.read()
    if len(content) > MAX_IMAGE_BYTES:
        raise HTTPException(400, f"Image exceeds {MAX_IMAGE_BYTES // (1024*1024)}MB limit")
    async with aiofiles.open(dest, "wb") as f:
        await f.write(content)
    avatar_url = f"/api/media/{filename}"

    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO users (name, email, password_hash, role, avatar_url) VALUES (%s, %s, %s, %s, %s) RETURNING *",
            (name, email, hash_password(password), role, avatar_url),
        )
        user = dict(cur.fetchone())
        conn.commit()
    except Exception as e:
        conn.rollback()
        dest.unlink(missing_ok=True)
        if "unique" in str(e).lower():
            raise HTTPException(400, "Email already registered")
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    token = create_token(user["id"])
    for f in ("password_hash", "reset_token", "reset_token_expires"):
        user.pop(f, None)
    return {"token": token, "user": user}


@api.post("/auth/login")
def login(body: LoginBody):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE email = %s", (body.email,))
    user = cur.fetchone()
    cur.close()
    conn.close()

    if not user or not verify_password(body.password, user["password_hash"]):
        raise HTTPException(401, "Invalid email or password")

    if user["is_suspended"]:
        raise HTTPException(403, f"Account suspended: {user['suspension_reason'] or 'Violation of community guidelines'}")

    token = create_token(user["id"])
    user = dict(user)
    for f in ("password_hash", "reset_token", "reset_token_expires"):
        user.pop(f, None)
    return {"token": token, "user": user}


@api.post("/auth/forgot-password")
def forgot_password(body: ForgotPasswordBody, request: Request):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id FROM users WHERE email = %s", (body.email,))
    user = cur.fetchone()
    
    if not user:
        cur.close()
        conn.close()
        # Return success anyway to prevent email enumeration
        return {"ok": True, "message": "If that email is registered, a reset link was created."}

    token = str(uuid.uuid4())
    expires = datetime.utcnow() + timedelta(hours=1)
    
    cur.execute(
        "UPDATE users SET reset_token = %s, reset_token_expires = %s WHERE id = %s",
        (token, expires, user["id"])
    )
    conn.commit()
    cur.close()
    conn.close()

    # In production, send the reset link via email.
    # For now, we store the token and the user must use the reset form with the token
    # from an actual email. We do NOT return the token in the API response.
    return {
        "ok": True,
        "message": "If that email is registered, a reset link has been sent.",
    }


@api.post("/auth/reset-password")
def reset_password(body: ResetPasswordBody):
    conn = get_conn()
    cur = conn.cursor()
    
    cur.execute(
        "SELECT id, reset_token_expires FROM users WHERE reset_token = %s", 
        (body.token,)
    )
    user = cur.fetchone()
    
    if not user:
        cur.close()
        conn.close()
        raise HTTPException(400, "Invalid or expired token")
        
    # Check expiry (make sure we handle timezone-aware vs naive properly)
    now = datetime.utcnow()
    # PostGres TIMESTAMPTZ comes back as a timezone-aware datetime in UTC
    # Since now is naive, we can just strip the tzinfo from the DB response for comparison
    expires_naive = user["reset_token_expires"].replace(tzinfo=None) if user["reset_token_expires"] else datetime.min
    
    if expires_naive < now:
        cur.close()
        conn.close()
        raise HTTPException(400, "Token has expired")
        
    hashed = hash_password(body.new_password)
    cur.execute(
        "UPDATE users SET password_hash = %s, reset_token = NULL, reset_token_expires = NULL WHERE id = %s",
        (hashed, user["id"])
    )
    conn.commit()
    cur.close()
    conn.close()
    
    return {"ok": True}


@api.get("/auth/me")
def me(current_user=Depends(get_current_user)):
    user = dict(current_user)
    for f in ("password_hash", "reset_token", "reset_token_expires"):
        user.pop(f, None)
    return user


@api.post("/auth/onboard")
def onboard(body: dict, current_user=Depends(get_current_user)):
    allowed = {"role", "location", "cuisine_type", "experience_level", "hours", "bio"}
    updates = {k: v for k, v in body.items() if k in allowed and v}
    if not updates:
        updates["onboarded"] = True
    else:
        updates["onboarded"] = True
    conn = get_conn()
    cur = conn.cursor()
    try:
        set_clause = ", ".join(f"{k} = %s" for k in updates)
        cur.execute(
            f"UPDATE users SET {set_clause} WHERE id = %s RETURNING *",
            list(updates.values()) + [current_user["id"]],
        )
        conn.commit()
        updated = dict(cur.fetchone())
    finally:
        cur.close()
        conn.close()
    for f in ("password_hash", "reset_token", "reset_token_expires"):
        updated.pop(f, None)
    return updated


# ── File Upload ────────────────────────────────────────────────────────────────
@api.post("/upload/video")
async def upload_video(file: UploadFile = File(...), current_user=Depends(get_current_user)):
    ext = Path(file.filename).suffix.lower() if file.filename else ".mp4"
    raw_filename = f"raw_{uuid.uuid4()}{ext}"
    raw_dest = UPLOAD_DIR / raw_filename

    # Save raw upload with size limit
    size = 0
    async with aiofiles.open(raw_dest, "wb") as f:
        while chunk := await file.read(1024 * 1024):  # 1MB chunks
            size += len(chunk)
            if size > MAX_VIDEO_BYTES:
                raw_dest.unlink(missing_ok=True)
                raise HTTPException(400, f"Video exceeds {MAX_VIDEO_BYTES // (1024*1024)}MB limit")
            await f.write(chunk)

    # Transcode to H.264 MP4 (faststart, capped 1080p, AAC audio)
    final_filename = f"{uuid.uuid4()}.mp4"
    final_dest = UPLOAD_DIR / final_filename
    ok = await transcode_video(raw_dest, final_dest)

    if ok:
        raw_dest.unlink(missing_ok=True)  # delete raw after successful transcode
        return {"url": f"/api/media/{final_filename}"}
    else:
        # Transcode failed — serve raw upload as fallback
        print(f"[FFmpeg] transcode failed, serving raw file: {raw_filename}")
        return {"url": f"/api/media/{raw_filename}"}


@api.post("/upload/image")
async def upload_image(file: UploadFile = File(...), current_user=Depends(get_current_user)):
    ext = Path(file.filename).suffix.lower() if file.filename else ".jpg"
    filename = f"{uuid.uuid4()}{ext}"
    dest = UPLOAD_DIR / filename
    size = 0
    async with aiofiles.open(dest, "wb") as f:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > MAX_IMAGE_BYTES:
                dest.unlink(missing_ok=True)
                raise HTTPException(400, f"Image exceeds {MAX_IMAGE_BYTES // (1024*1024)}MB limit")
            await f.write(chunk)
    return {"url": f"/api/media/{filename}"}


@api.get("/media/{filename}")
async def serve_media(filename: str):
    # Resolve and validate path to prevent traversal attacks
    resolved = (UPLOAD_DIR / filename).resolve()
    if not str(resolved).startswith(str(UPLOAD_DIR.resolve())):
        raise HTTPException(403, "Access denied")
    if not resolved.exists():
        raise HTTPException(404, "File not found")
    # Cache media for 30 days, mark as immutable since filenames are UUIDs
    return FileResponse(
        str(resolved),
        headers={
            "Cache-Control": "public, max-age=2592000, immutable",
        },
    )


# ── Videos ────────────────────────────────────────────────────────────────────
@api.get("/videos")
def list_videos(
    type: Optional[str] = None,
    user_id: Optional[int] = None,
    q: Optional[str] = None,
    location: Optional[str] = None,
    cuisine_type: Optional[str] = None,
    category: Optional[str] = None,
    experience_level: Optional[str] = None,
    current_user=Depends(get_optional_user),
):
    conn = get_conn()
    cur = conn.cursor()

    query = """
        SELECT v.*, u.name as author_name, u.avatar_url as author_avatar, u.avg_rating as author_rating, u.role as author_role, u.is_admin as author_is_admin, u.is_advertiser as author_is_advertiser
        FROM videos v JOIN users u ON v.user_id = u.id
        WHERE 1=1
    """
    params = []
    if type:
        query += " AND v.type = %s"
        params.append(type)
    if user_id:
        query += " AND v.user_id = %s"
        params.append(user_id)
    if q:
        query += " AND (v.title ILIKE %s OR v.description ILIKE %s OR v.cuisine_type ILIKE %s OR v.location ILIKE %s OR u.name ILIKE %s)"
        term = f"%{q}%"
        params.extend([term, term, term, term, term])
    if location:
        query += " AND v.location ILIKE %s"
        params.append(f"%{location}%")
    if cuisine_type:
        query += " AND v.cuisine_type ILIKE %s"
        params.append(f"%{cuisine_type}%")
    if category and category != "all":
        query += " AND v.category = %s"
        params.append(category)
    if experience_level:
        query += " AND v.experience_level = %s"
        params.append(experience_level)
    # Hide scheduled posts that haven't gone live yet (unless viewing own posts)
    if current_user:
        query += " AND (v.scheduled_at IS NULL OR v.scheduled_at <= NOW() OR v.user_id = %s)"
        params.append(current_user["id"])
    else:
        query += " AND (v.scheduled_at IS NULL OR v.scheduled_at <= NOW())"

    # Randomize order for the main "all" feed; recent-first when filtered
    if not type and (not category or category == "all") and not q and not user_id:
        query += " ORDER BY RANDOM()"
    else:
        query += " ORDER BY v.created_at DESC"

    cur.execute(query, params)
    videos = [dict(r) for r in cur.fetchall()]

    # check which ones the current user liked
    liked_ids = set()
    if current_user:
        cur.execute("SELECT video_id FROM likes WHERE user_id = %s", (current_user["id"],))
        liked_ids = {r["video_id"] for r in cur.fetchall()}

    cur.close()
    conn.close()

    for v in videos:
        v["liked_by_me"] = v["id"] in liked_ids
        # make timestamps JSON serializable
        if v.get("created_at"):
            v["created_at"] = v["created_at"].isoformat()
            
        # Hide worker pay rates from other workers/anonymous users
        if v["type"] == "worker":
            if not current_user or (current_user["role"] != "employer" and current_user["id"] != v["user_id"]):
                v["pay_rate"] = ""

    return videos


@api.post("/videos")
def create_video(
    type: str = Form(...),
    title: str = Form(""),
    video_url: str = Form(""),
    image_url: str = Form(""),
    post_type: str = Form("video"),
    category: str = Form("general"),
    price: str = Form(""),
    event_date: str = Form(""),
    event_time: str = Form(""),
    scheduled_at: str = Form(""),
    aspect_ratio: str = Form("9:16"),
    description: str = Form(""),
    cuisine_type: str = Form(""),
    pay_rate: str = Form(""),
    hours: str = Form(""),
    experience_level: str = Form(""),
    location: str = Form(""),
    current_user=Depends(get_current_user),
):
    # Validate: must have at least some content
    has_media = bool(video_url or image_url)
    has_text = bool(title.strip() or description.strip())
    if not has_media and not has_text:
        raise HTTPException(400, "Post must have a title, description, image, or video")

    # Validate aspect ratio
    if aspect_ratio not in ("9:16", "1:1", "4:5", "16:9"):
        aspect_ratio = "9:16"

    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            """INSERT INTO videos (user_id, video_url, image_url, type, post_type, category, price, event_date, event_time, scheduled_at, aspect_ratio, title, description, cuisine_type, pay_rate, hours, experience_level, location)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s) RETURNING *""",
            (current_user["id"], video_url or None, image_url or None, type, post_type, category, price, event_date, event_time, scheduled_at or None, aspect_ratio, title or None, description, cuisine_type, pay_rate, hours, experience_level, location),
        )
        video = dict(cur.fetchone())
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    if video.get("created_at"):
        video["created_at"] = video["created_at"].isoformat()
    if video.get("scheduled_at"):
        video["scheduled_at"] = video["scheduled_at"].isoformat()
    return video


@api.post("/videos/{video_id}/like")
def toggle_like(video_id: int, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute("SELECT id FROM likes WHERE user_id=%s AND video_id=%s", (current_user["id"], video_id))
        existing = cur.fetchone()
        if existing:
            cur.execute("DELETE FROM likes WHERE user_id=%s AND video_id=%s", (current_user["id"], video_id))
            cur.execute("UPDATE videos SET likes = likes - 1 WHERE id = %s RETURNING likes", (video_id,))
            liked = False
        else:
            cur.execute("INSERT INTO likes (user_id, video_id) VALUES (%s, %s)", (current_user["id"], video_id))
            cur.execute("UPDATE videos SET likes = likes + 1 WHERE id = %s RETURNING likes", (video_id,))
            liked = True
        row = cur.fetchone()
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()
    return {"liked": liked, "likes": row["likes"] if row else 0}


@api.patch("/videos/{video_id}")
async def update_video(
    video_id: int,
    title: str = Form(None),
    description: str = Form(None),
    repost: str = Form("false"),
    category: str = Form(None),
    price: str = Form(None),
    event_date: str = Form(None),
    event_time: str = Form(None),
    file: UploadFile = File(None),
    current_user=Depends(get_current_user),
):
    conn = get_conn()
    cur = conn.cursor()
    try:
        # verify ownership
        cur.execute("SELECT user_id FROM videos WHERE id = %s", (video_id,))
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Video not found")
        if row["user_id"] != current_user["id"] and current_user["role"] != "admin":
            raise HTTPException(403, "Not authorized to edit this post")

        updates = []
        params = []
        
        if file is not None and file.filename:
            ext = Path(file.filename).suffix.lower()
            if ext in (".mp4", ".mov", ".webm"):
                new_filename = f"vid_{uuid.uuid4()}{ext}"
                dest = UPLOAD_DIR / new_filename
                content = await file.read()
                async with aiofiles.open(dest, "wb") as f:
                    await f.write(content)
                updates.append("video_url = %s")
                params.append(f"/api/media/{new_filename}")
                updates.append("image_url = NULL")
            elif ext in (".jpg", ".jpeg", ".png", ".gif", ".webp"):
                new_filename = f"img_{uuid.uuid4()}{ext}"
                dest = UPLOAD_DIR / new_filename
                content = await file.read()
                async with aiofiles.open(dest, "wb") as f:
                    await f.write(content)
                updates.append("image_url = %s")
                params.append(f"/api/media/{new_filename}")
                updates.append("video_url = NULL")
        
        if title is not None:
            updates.append("title = %s")
            params.append(title)
        if description is not None:
            updates.append("description = %s")
            params.append(description)
        if category is not None:
            updates.append("category = %s")
            params.append(category)
        if price is not None:
            updates.append("price = %s")
            params.append(price)
        if event_date is not None:
            updates.append("event_date = %s")
            params.append(event_date)
        if event_time is not None:
            updates.append("event_time = %s")
            params.append(event_time)
            
        if str(repost).lower() == "true":
            updates.append("created_at = CURRENT_TIMESTAMP")

        if not updates:
            return {"ok": True}

        params.append(video_id)
        
        cur.execute(f"UPDATE videos SET {', '.join(updates)} WHERE id = %s RETURNING *", tuple(params))
        video = dict(cur.fetchone())
        conn.commit()
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()
    
    if video.get("created_at"):
        video["created_at"] = video["created_at"].isoformat()
    return video

@api.delete("/videos/{video_id}")
def delete_video(video_id: int, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT user_id FROM videos WHERE id = %s", (video_id,))
    video = cur.fetchone()
    if not video:
        raise HTTPException(404, "Video not found")
    if video["user_id"] != current_user["id"]:
        raise HTTPException(403, "Not your video")
    cur.execute("DELETE FROM videos WHERE id = %s", (video_id,))
    conn.commit()
    cur.close()
    conn.close()
    return {"deleted": True}


# ── Matches ────────────────────────────────────────────────────────────────────
@api.get("/matches")
def list_matches(current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    uid = current_user["id"]
    cur.execute(
        """SELECT m.*,
            w.name as worker_name, w.avatar_url as worker_avatar,
            e.name as employer_name, e.avatar_url as employer_avatar,
            ev.location as employer_location
           FROM matches m
           JOIN users w ON m.worker_id = w.id
           JOIN users e ON m.employer_id = e.id
           LEFT JOIN videos ev ON m.employer_video_id = ev.id
           WHERE m.worker_id = %s OR m.employer_id = %s
           ORDER BY m.created_at DESC""",
        (uid, uid),
    )
    matches = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for m in matches:
        if m.get("created_at"):
            m["created_at"] = m["created_at"].isoformat()
    return matches


@api.post("/matches")
def create_match(body: MatchBody, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()

    # Determine worker and employer from the current user and the target video
    # At least one video ID must be provided
    worker_video_id = body.worker_video_id
    employer_video_id = body.employer_video_id

    worker_id = None
    employer_id = None

    if employer_video_id:
        cur.execute("SELECT user_id, type FROM videos WHERE id = %s", (employer_video_id,))
        ev = cur.fetchone()
        if not ev:
            raise HTTPException(404, "Spot video not found")
        employer_id = ev["user_id"]

    if worker_video_id:
        cur.execute("SELECT user_id, type FROM videos WHERE id = %s", (worker_video_id,))
        wv = cur.fetchone()
        if not wv:
            raise HTTPException(404, "Crew video not found")
        worker_id = wv["user_id"]

    # If only one video provided, the current user is the other party
    if worker_video_id and not employer_video_id:
        # Worker liked an employer's post but had no video to attach
        employer_id = None  # we need to figure it out from context
        # Current user is the worker
        worker_id_from_video = worker_id
        if current_user["role"] == "worker":
            worker_id = current_user["id"]
            # Find the employer from the video
            employer_id = None  # still unknown without a video
        else:
            worker_id = worker_id_from_video
            employer_id = current_user["id"]
    elif employer_video_id and not worker_video_id:
        # Employer liked a worker's post but had no video to attach
        if current_user["role"] == "employer":
            employer_id = employer_id  # already set from video query
            worker_id = None  # need to find from video
        else:
            worker_id = current_user["id"]

    # Simpler approach: use the video to find the other user, current user is the initiator
    # Re-derive cleanly
    if employer_video_id and not worker_video_id:
        # Current user saw an employer video → current user is the worker
        worker_id = current_user["id"]
        # employer_id already set from video query above
    elif worker_video_id and not employer_video_id:
        # Current user saw a worker video → current user is the employer
        employer_id = current_user["id"]
        # worker_id already set from video query above

    if not worker_id or not employer_id:
        raise HTTPException(400, "Could not determine match participants")

    if worker_id == employer_id:
        raise HTTPException(400, "Cannot match with yourself")

    # Check for duplicate
    cur.execute(
        "SELECT id FROM matches WHERE worker_id=%s AND employer_id=%s AND status != 'cancelled'",
        (worker_id, employer_id),
    )
    if cur.fetchone():
        raise HTTPException(400, "Match already exists")

    try:
        cur.execute(
            """INSERT INTO matches (worker_id, employer_id, worker_video_id, employer_video_id, status, initiated_by)
               VALUES (%s, %s, %s, %s, 'pending', %s) RETURNING *""",
            (worker_id, employer_id, worker_video_id, employer_video_id, current_user["id"]),
        )
        match = dict(cur.fetchone())
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    if match.get("created_at"):
        match["created_at"] = match["created_at"].isoformat()
    return match


@api.post("/matches/{match_id}/confirm")
def confirm_match(match_id: int, current_user=Depends(get_current_user)):
    """Both parties confirming shift completion."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM matches WHERE id = %s", (match_id,))
    match = cur.fetchone()
    if not match:
        raise HTTPException(404, "Match not found")
    match = dict(match)

    uid = current_user["id"]
    if uid == match["worker_id"]:
        cur.execute("UPDATE matches SET worker_confirmed=TRUE WHERE id=%s", (match_id,))
    elif uid == match["employer_id"]:
        cur.execute("UPDATE matches SET employer_confirmed=TRUE WHERE id=%s", (match_id,))
    else:
        raise HTTPException(403, "Not part of this match")

    # Check if both confirmed
    cur.execute("SELECT worker_confirmed, employer_confirmed FROM matches WHERE id=%s", (match_id,))
    updated = dict(cur.fetchone())
    if updated["worker_confirmed"] and updated["employer_confirmed"]:
        cur.execute("UPDATE matches SET status='completed' WHERE id=%s", (match_id,))

    conn.commit()
    cur.close()
    conn.close()
    return {"confirmed": True, "both_confirmed": updated["worker_confirmed"] and updated["employer_confirmed"]}


@api.post("/matches/{match_id}/accept")
def accept_match(match_id: int, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM matches WHERE id=%s", (match_id,))
    match = cur.fetchone()
    if not match:
        raise HTTPException(404, "Match not found")
    match = dict(match)
    uid = current_user["id"]
    if uid not in (match["worker_id"], match["employer_id"]):
        raise HTTPException(403, "Not part of this match")
    if match["status"] != "pending":
        raise HTTPException(400, f"Match is {match['status']}, not pending")
    if uid == match["initiated_by"]:
        raise HTTPException(400, "You initiated this match — wait for the other person to accept")
    cur.execute("UPDATE matches SET status='active' WHERE id=%s", (match_id,))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "active"}


@api.post("/matches/{match_id}/decline")
def decline_match(match_id: int, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM matches WHERE id=%s", (match_id,))
    match = cur.fetchone()
    if not match:
        raise HTTPException(404, "Match not found")
    match = dict(match)
    uid = current_user["id"]
    if uid not in (match["worker_id"], match["employer_id"]):
        raise HTTPException(403, "Not part of this match")
    if match["status"] != "pending":
        raise HTTPException(400, f"Match is {match['status']}, not pending")
    if uid == match["initiated_by"]:
        raise HTTPException(400, "You initiated this match — you can cancel it instead")
    cur.execute("UPDATE matches SET status='cancelled' WHERE id=%s", (match_id,))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "cancelled"}


@api.post("/matches/{match_id}/cancel")
def cancel_match(match_id: int, current_user=Depends(get_current_user)):
    """Initiator can cancel their pending match request."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM matches WHERE id=%s", (match_id,))
    match = cur.fetchone()
    if not match:
        raise HTTPException(404, "Match not found")
    match = dict(match)
    uid = current_user["id"]
    if uid not in (match["worker_id"], match["employer_id"]):
        raise HTTPException(403, "Not part of this match")
    if match["status"] != "pending":
        raise HTTPException(400, f"Match is {match['status']}, can only cancel pending matches")
    cur.execute("UPDATE matches SET status='cancelled' WHERE id=%s", (match_id,))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "cancelled"}


# ── Messages ───────────────────────────────────────────────────────────────────
@api.get("/matches/{match_id}/messages")
def get_messages(match_id: int, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM matches WHERE id=%s AND (worker_id=%s OR employer_id=%s)",
                (match_id, current_user["id"], current_user["id"]))
    match = cur.fetchone()
    if not match:
        raise HTTPException(403, "Not part of this match")
    if dict(match)["status"] == "pending":
        raise HTTPException(400, "Messages are available after the match is accepted")

    cur.execute(
        """SELECT m.*, u.name as sender_name, u.avatar_url as sender_avatar
           FROM messages m JOIN users u ON m.sender_id = u.id
           WHERE m.match_id = %s ORDER BY m.created_at ASC""",
        (match_id,),
    )
    msgs = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for m in msgs:
        if m.get("created_at"):
            m["created_at"] = m["created_at"].isoformat()
    return msgs


@api.post("/matches/{match_id}/messages")
def send_message(match_id: int, body: MessageBody, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM matches WHERE id=%s AND (worker_id=%s OR employer_id=%s)",
                (match_id, current_user["id"], current_user["id"]))
    match = cur.fetchone()
    if not match:
        raise HTTPException(403, "Not part of this match")
    if dict(match)["status"] == "pending":
        raise HTTPException(400, "Messages are available after the match is accepted")

    try:
        cur.execute(
            "INSERT INTO messages (match_id, sender_id, content) VALUES (%s, %s, %s) RETURNING *",
            (match_id, current_user["id"], body.content),
        )
        msg = dict(cur.fetchone())
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    if msg.get("created_at"):
        msg["created_at"] = msg["created_at"].isoformat()
    msg["sender_name"] = current_user["name"]
    msg["sender_avatar"] = current_user["avatar_url"]
    return msg


# ── Reviews ────────────────────────────────────────────────────────────────────
@api.post("/matches/{match_id}/review/{reviewee_id}")
def post_review(match_id: int, reviewee_id: int, body: ReviewBody, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM matches WHERE id=%s AND status='completed'", (match_id,))
    match = cur.fetchone()
    if not match:
        raise HTTPException(400, "Match not completed yet")
    uid = current_user["id"]
    if uid not in (match["worker_id"], match["employer_id"]):
        raise HTTPException(403, "Not part of this match")

    try:
        cur.execute(
            "INSERT INTO reviews (match_id, reviewer_id, reviewee_id, rating, feedback) VALUES (%s,%s,%s,%s,%s)",
            (match_id, uid, reviewee_id, body.rating, body.feedback),
        )
        # Update avg rating on reviewee
        cur.execute(
            """UPDATE users SET avg_rating = (
                SELECT AVG(rating) FROM reviews WHERE reviewee_id = %s
               ), total_shifts = total_shifts + 1
               WHERE id = %s""",
            (reviewee_id, reviewee_id),
        )
        conn.commit()
    except Exception as e:
        conn.rollback()
        if "unique" in str(e).lower():
            raise HTTPException(400, "Already reviewed this match")
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    return {"ok": True}


@api.get("/users/{user_id}/reviews")
def get_user_reviews(user_id: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT r.*, u.name as reviewer_name, u.avatar_url as reviewer_avatar
           FROM reviews r JOIN users u ON r.reviewer_id = u.id
           WHERE r.reviewee_id = %s ORDER BY r.created_at DESC""",
        (user_id,),
    )
    reviews = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for r in reviews:
        if r.get("created_at"):
            r["created_at"] = r["created_at"].isoformat()
    return reviews


@api.get("/users/{user_id}")
def get_user(user_id: int):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = %s", (user_id,))
    user = cur.fetchone()
    cur.close()
    conn.close()
    if not user:
        raise HTTPException(404, "User not found")
    user = dict(user)
    # Remove sensitive fields
    for field in ("password_hash", "reset_token", "reset_token_expires"):
        user.pop(field, None)
    if user.get("created_at"):
        user["created_at"] = user["created_at"].isoformat()
    return user


@api.patch("/users/me")
def update_profile(body: ProfileUpdateBody, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    updates = {}
    if body.name:
        updates["name"] = body.name
    if body.bio is not None:
        updates["bio"] = body.bio
    if body.email:
        updates["email"] = body.email

    if updates:
        set_clause = ", ".join(f"{k} = %s" for k in updates)
        cur.execute(
            f"UPDATE users SET {set_clause} WHERE id = %s RETURNING *",
            list(updates.values()) + [current_user["id"]],
        )
        user = dict(cur.fetchone())
        conn.commit()
    else:
        user = current_user

    cur.close()
    conn.close()
    for f in ("password_hash", "reset_token", "reset_token_expires"):
        user.pop(f, None)
    if user.get("created_at"):
        user["created_at"] = user["created_at"].isoformat()
    return user


@api.delete("/users/me")
def delete_account(current_user=Depends(get_current_user)):
    """Permanently delete the user account and all associated data."""
    conn = get_conn()
    cur = conn.cursor()
    try:
        user_id = current_user["id"]
        # Cascade: messages, likes, matches, reviews, videos, then user
        cur.execute("DELETE FROM messages WHERE sender_id = %s", (user_id,))
        cur.execute("DELETE FROM likes WHERE user_id = %s", (user_id,))
        cur.execute("DELETE FROM matches WHERE worker_id = %s OR employer_id = %s", (user_id, user_id))
        cur.execute("DELETE FROM reviews WHERE reviewer_id = %s OR reviewee_id = %s", (user_id, user_id))
        cur.execute("DELETE FROM videos WHERE user_id = %s", (user_id,))
        cur.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()
    return {"ok": True}


@api.patch("/users/me/avatar")
async def update_avatar(file: UploadFile = File(...), current_user=Depends(get_current_user)):
    ext = Path(file.filename).suffix.lower() if file.filename else ".jpg"
    filename = f"avatar_{uuid.uuid4()}{ext}"
    dest = UPLOAD_DIR / filename
    content = await file.read()
    if len(content) > MAX_IMAGE_BYTES:
        raise HTTPException(400, f"Image exceeds {MAX_IMAGE_BYTES // (1024*1024)}MB limit")
    async with aiofiles.open(dest, "wb") as f:
        await f.write(content)
    url = f"/api/media/{filename}"

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE users SET avatar_url=%s WHERE id=%s RETURNING *", (url, current_user["id"]))
    user = dict(cur.fetchone())
    conn.commit()
    cur.close()
    conn.close()
    for f in ("password_hash", "reset_token", "reset_token_expires"):
        user.pop(f, None)
    return user


# ── Admin ──────────────────────────────────────────────────────────────────────

@api.get("/admin/stats")
def admin_stats(admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    stats = {}
    cur.execute("SELECT COUNT(*) FROM users")
    stats["total_users"] = cur.fetchone()["count"]
    cur.execute("SELECT COUNT(*) FROM users WHERE role='worker'")
    stats["workers"] = cur.fetchone()["count"]
    cur.execute("SELECT COUNT(*) FROM users WHERE role='employer'")
    stats["employers"] = cur.fetchone()["count"]
    cur.execute("SELECT COUNT(*) FROM videos")
    stats["total_videos"] = cur.fetchone()["count"]
    cur.execute("SELECT COUNT(*) FROM matches")
    stats["total_matches"] = cur.fetchone()["count"]
    cur.execute("SELECT COUNT(*) FROM matches WHERE status='pending'")
    stats["pending_matches"] = cur.fetchone()["count"]
    cur.execute("SELECT COUNT(*) FROM matches WHERE status='active'")
    stats["active_matches"] = cur.fetchone()["count"]
    cur.execute("SELECT COUNT(*) FROM matches WHERE status='completed'")
    stats["completed_matches"] = cur.fetchone()["count"]
    # Signups in last 7 days
    cur.execute("SELECT COUNT(*) FROM users WHERE created_at > NOW() - INTERVAL '7 days'")
    stats["signups_last_7d"] = cur.fetchone()["count"]
    # Signups today
    cur.execute("SELECT COUNT(*) FROM users WHERE created_at > NOW() - INTERVAL '1 day'")
    stats["signups_today"] = cur.fetchone()["count"]
    cur.close()
    conn.close()
    return stats


@api.get("/admin/users")
def admin_list_users(admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT id, name, email, role, is_admin, is_advertiser, advertiser_agreement_accepted, avg_rating, total_shifts,
                  avatar_url, created_at, bio
           FROM users ORDER BY created_at DESC"""
    )
    users = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for u in users:
        if u.get("created_at"):
            u["created_at"] = u["created_at"].isoformat()
    return users


@api.patch("/admin/users/{user_id}")
def admin_update_user(user_id: int, body: dict, admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id=%s", (user_id,))
    if not cur.fetchone():
        raise HTTPException(404, "User not found")
    allowed = {"is_admin", "is_advertiser"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(400, "No valid fields to update")
    set_clause = ", ".join(f"{k} = %s" for k in updates)
    cur.execute(f"UPDATE users SET {set_clause} WHERE id=%s RETURNING *",
                list(updates.values()) + [user_id])
    user = dict(cur.fetchone())
    conn.commit()
    cur.close()
    conn.close()
    for f in ("password_hash", "reset_token", "reset_token_expires"):
        user.pop(f, None)
    return user


@api.delete("/admin/users/{user_id}")
def admin_delete_user(user_id: int, admin=Depends(require_admin)):
    if user_id == admin["id"]:
        raise HTTPException(400, "Cannot delete your own account")
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute("DELETE FROM messages WHERE sender_id = %s", (user_id,))
        cur.execute("DELETE FROM likes WHERE user_id = %s", (user_id,))
        cur.execute("DELETE FROM matches WHERE worker_id = %s OR employer_id = %s", (user_id, user_id))
        cur.execute("DELETE FROM reviews WHERE reviewer_id = %s OR reviewee_id = %s", (user_id, user_id))
        cur.execute("DELETE FROM videos WHERE user_id = %s", (user_id,))
        cur.execute("DELETE FROM users WHERE id = %s", (user_id,))
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()
    return {"ok": True}


# ── Advertiser Agreement ──────────────────────────────────────────────────────
@api.post("/advertiser/agreement")
def accept_advertiser_agreement(current_user=Depends(get_current_user)):
    if not current_user.get("is_advertiser"):
        raise HTTPException(403, "Not an advertiser")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "UPDATE users SET advertiser_agreement_accepted = TRUE WHERE id = %s RETURNING id",
        (current_user["id"],),
    )
    conn.commit()
    cur.close()
    conn.close()
    return {"ok": True, "advertiser_agreement_accepted": True}


@api.get("/admin/videos")
def admin_list_videos(admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT v.*, u.name as user_name, u.role as user_role
           FROM videos v JOIN users u ON v.user_id = u.id
           ORDER BY v.created_at DESC"""
    )
    videos = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for v in videos:
        if v.get("created_at"):
            v["created_at"] = v["created_at"].isoformat()
    return videos


@api.delete("/admin/videos/{video_id}")
def admin_delete_video(video_id: int, admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM videos WHERE id=%s", (video_id,))
    video = cur.fetchone()
    if not video:
        raise HTTPException(404, "Video not found")
    try:
        cur.execute("DELETE FROM likes WHERE video_id = %s", (video_id,))
        cur.execute("DELETE FROM videos WHERE id = %s", (video_id,))
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()
    return {"ok": True}


@api.get("/admin/scheduled")
def admin_list_scheduled(admin=Depends(require_admin)):
    """List all posts with a scheduled_at that haven't gone live yet."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT v.id, v.title, v.description, v.type, v.category, v.scheduled_at, v.created_at,
                  v.image_url, v.video_url,
                  u.id as user_id, u.name as user_name, u.role as user_role, u.is_advertiser
           FROM videos v JOIN users u ON v.user_id = u.id
           WHERE v.scheduled_at IS NOT NULL AND v.scheduled_at > NOW()
           ORDER BY v.scheduled_at ASC"""
    )
    rows = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for r in rows:
        if r.get("scheduled_at"):
            r["scheduled_at"] = r["scheduled_at"].isoformat()
        if r.get("created_at"):
            r["created_at"] = r["created_at"].isoformat()
    return rows


@api.get("/admin/matches")
def admin_list_matches(admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT m.*, w.name as worker_name, e.name as employer_name
           FROM matches m
           JOIN users w ON m.worker_id = w.id
           JOIN users e ON m.employer_id = e.id
           ORDER BY m.created_at DESC"""
    )
    matches = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for m in matches:
        if m.get("created_at"):
            m["created_at"] = m["created_at"].isoformat()
    return matches


# ── Reports & Moderation ──────────────────────────────────────────────────────

class ReportBody(BaseModel):
    target_type: str  # "video" or "user"
    target_id: int
    reason: str       # harassment, spam, inappropriate, fake, other
    comment: Optional[str] = None


@api.post("/reports")
def create_report(body: ReportBody, current_user=Depends(get_current_user)):
    if body.target_type not in ("video", "user"):
        raise HTTPException(400, "target_type must be 'video' or 'user'")
    if body.reason not in ("harassment", "spam", "inappropriate", "fake", "other"):
        raise HTTPException(400, "Invalid reason")

    # Can't report yourself
    if body.target_type == "user" and body.target_id == current_user["id"]:
        raise HTTPException(400, "Cannot report yourself")

    # Prevent duplicate reports from same user on same target
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT id FROM reports WHERE reporter_id=%s AND target_type=%s AND target_id=%s AND status='open'",
        (current_user["id"], body.target_type, body.target_id),
    )
    if cur.fetchone():
        raise HTTPException(400, "You already reported this")

    try:
        cur.execute(
            """INSERT INTO reports (reporter_id, target_type, target_id, reason, comment)
               VALUES (%s, %s, %s, %s, %s) RETURNING *""",
            (current_user["id"], body.target_type, body.target_id, body.reason, body.comment),
        )
        report = dict(cur.fetchone())

        # Auto-flag: if 3+ open reports on same target, auto-suspend user or flag for urgent review
        cur.execute(
            "SELECT COUNT(*) FROM reports WHERE target_type=%s AND target_id=%s AND status='open'",
            (body.target_type, body.target_id),
        )
        report_count = cur.fetchone()["count"]

        if report_count >= 3:
            if body.target_type == "user":
                cur.execute(
                    "UPDATE users SET is_suspended=TRUE, suspension_reason='Auto-suspended: multiple reports' WHERE id=%s",
                    (body.target_id,),
                )
            elif body.target_type == "video":
                # Find the video owner and suspend them
                cur.execute("SELECT user_id FROM videos WHERE id=%s", (body.target_id,))
                vid = cur.fetchone()
                if vid:
                    cur.execute(
                        "UPDATE users SET is_suspended=TRUE, suspension_reason='Auto-suspended: video received multiple reports' WHERE id=%s",
                        (vid["user_id"],),
                    )

        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    if report.get("created_at"):
        report["created_at"] = report["created_at"].isoformat()
    return report


@api.get("/admin/reports")
def admin_list_reports(admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT r.*,
            reporter.name as reporter_name,
            CASE
                WHEN r.target_type = 'user' THEN target_u.name
                WHEN r.target_type = 'video' THEN target_v.title
            END as target_name,
            CASE
                WHEN r.target_type = 'user' THEN target_u.email
                WHEN r.target_type = 'video' THEN target_v.title
            END as target_detail
           FROM reports r
           JOIN users reporter ON r.reporter_id = reporter.id
           LEFT JOIN users target_u ON r.target_type = 'user' AND r.target_id = target_u.id
           LEFT JOIN videos target_v ON r.target_type = 'video' AND r.target_id = target_v.id
           ORDER BY
             CASE WHEN r.status = 'open' THEN 0 ELSE 1 END,
             r.created_at DESC"""
    )
    reports = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for r in reports:
        if r.get("created_at"):
            r["created_at"] = r["created_at"].isoformat()
        if r.get("reviewed_at"):
            r["reviewed_at"] = r["reviewed_at"].isoformat()
    return reports


class ReviewReportBody(BaseModel):
    action: str  # dismiss, warn, suspend, remove_content
    reason: Optional[str] = None


@api.patch("/admin/reports/{report_id}")
def admin_review_report(report_id: int, body: ReviewReportBody, admin=Depends(require_admin)):
    if body.action not in ("dismiss", "warn", "suspend", "remove_content"):
        raise HTTPException(400, "Invalid action. Use: dismiss, warn, suspend, remove_content")

    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM reports WHERE id=%s", (report_id,))
    report = cur.fetchone()
    if not report:
        raise HTTPException(404, "Report not found")
    report = dict(report)

    try:
        # Update report status
        cur.execute(
            "UPDATE reports SET status='reviewed', admin_action=%s, reviewed_by=%s, reviewed_at=NOW() WHERE id=%s",
            (body.action, admin["id"], report_id),
        )

        if body.action == "suspend":
            # Suspend the target user
            if report["target_type"] == "user":
                cur.execute(
                    "UPDATE users SET is_suspended=TRUE, suspension_reason=%s WHERE id=%s",
                    (body.reason or "Suspended by admin", report["target_id"]),
                )
            elif report["target_type"] == "video":
                cur.execute("SELECT user_id FROM videos WHERE id=%s", (report["target_id"],))
                vid = cur.fetchone()
                if vid:
                    cur.execute(
                        "UPDATE users SET is_suspended=TRUE, suspension_reason=%s WHERE id=%s",
                        (body.reason or "Suspended by admin: video violation", vid["user_id"]),
                    )

        elif body.action == "remove_content":
            if report["target_type"] == "video":
                cur.execute("DELETE FROM likes WHERE video_id=%s", (report["target_id"],))
                cur.execute("DELETE FROM videos WHERE id=%s", (report["target_id"],))
            elif report["target_type"] == "user":
                # Remove all user's videos
                cur.execute("DELETE FROM likes WHERE video_id IN (SELECT id FROM videos WHERE user_id=%s)", (report["target_id"],))
                cur.execute("DELETE FROM videos WHERE user_id=%s", (report["target_id"],))

        # Also resolve all other open reports on the same target
        cur.execute(
            "UPDATE reports SET status='resolved', reviewed_by=%s, reviewed_at=NOW() WHERE target_type=%s AND target_id=%s AND status='open' AND id != %s",
            (admin["id"], report["target_type"], report["target_id"], report_id),
        )

        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    return {"ok": True, "action": body.action}


@api.post("/admin/users/{user_id}/suspend")
def admin_suspend_user(user_id: int, body: dict, admin=Depends(require_admin)):
    reason = body.get("reason", "Suspended by admin")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE users SET is_suspended=TRUE, suspension_reason=%s WHERE id=%s", (reason, user_id))
    conn.commit()
    cur.close()
    conn.close()
    return {"ok": True}


@api.post("/admin/users/{user_id}/unsuspend")
def admin_unsuspend_user(user_id: int, admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE users SET is_suspended=FALSE, suspension_reason=NULL WHERE id=%s", (user_id,))
    conn.commit()
    cur.close()
    conn.close()
    return {"ok": True}


# ── Support / Contact ─────────────────────────────────────────────────────────

AUTO_REPLY = (
    "Thanks for reaching out to Day Shift! 🧡\n\n"
    "We've received your message and our team will get back to you as soon as possible — "
    "typically within 24 hours.\n\n"
    "In the meantime, check out the feed for the latest shifts and opportunities.\n\n"
    "— The Day Shift Team"
)


@api.post("/support")
def create_support_thread(body: dict, current_user=Depends(get_current_user)):
    """User sends a message to admin. Creates a thread or adds to existing open thread."""
    subject = body.get("subject", "").strip()
    message = body.get("message", "").strip()
    if not message:
        raise HTTPException(400, "Message is required")

    conn = get_conn()
    cur = conn.cursor()
    try:
        # Find or create an open thread for this user
        cur.execute(
            "SELECT id FROM support_threads WHERE user_id = %s AND status = 'open' ORDER BY updated_at DESC LIMIT 1",
            (current_user["id"],),
        )
        thread = cur.fetchone()

        if thread:
            thread_id = thread["id"]
            cur.execute("UPDATE support_threads SET updated_at = NOW() WHERE id = %s", (thread_id,))
        else:
            cur.execute(
                "INSERT INTO support_threads (user_id, subject, status, source) VALUES (%s, %s, 'open', 'app') RETURNING id",
                (current_user["id"], subject or "Support Request"),
            )
            thread_id = cur.fetchone()["id"]

        # Insert user message
        cur.execute(
            "INSERT INTO support_messages (thread_id, sender_id, sender_role, content) VALUES (%s, %s, 'user', %s) RETURNING *",
            (thread_id, current_user["id"], message),
        )
        user_msg = dict(cur.fetchone())

        # Auto-reply from admin
        cur.execute(
            "INSERT INTO support_messages (thread_id, sender_id, sender_role, content) VALUES (%s, %s, 'auto', %s) RETURNING *",
            (thread_id, current_user["id"], AUTO_REPLY),
        )
        auto_msg = dict(cur.fetchone())

        conn.commit()

        for m in (user_msg, auto_msg):
            if m.get("created_at"):
                m["created_at"] = m["created_at"].isoformat()

        return {
            "thread_id": thread_id,
            "message": user_msg,
            "auto_reply": auto_msg,
        }
    finally:
        cur.close()
        conn.close()


@api.post("/support/guest")
def guest_support(body: dict):
    """Non-logged-in user sends a support message."""
    name = body.get("name", "").strip()
    email = body.get("email", "").strip()
    message = body.get("message", "").strip()
    if not message or not name or not email:
        raise HTTPException(400, "Name, email, and message are required")

    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO support_threads (user_id, subject, status, source) VALUES (NULL, %s, 'open', 'guest') RETURNING id",
            (f"Guest: {name} ({email})",),
        )
        thread_id = cur.fetchone()["id"]

        cur.execute(
            "INSERT INTO support_messages (thread_id, sender_id, sender_role, content) VALUES (%s, NULL, 'user', %s)",
            (thread_id, f"[Guest] {name} ({email}):\n\n{message}"),
        )

        conn.commit()
        return {"status": "ok", "thread_id": thread_id}
    finally:
        cur.close()
        conn.close()


@api.get("/support")
def list_my_threads(current_user=Depends(get_current_user)):
    """User sees their own support threads."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT t.*, 
                  (SELECT content FROM support_messages WHERE thread_id = t.id ORDER BY created_at DESC LIMIT 1) as last_message,
                  (SELECT COUNT(*) FROM support_messages WHERE thread_id = t.id AND sender_role != 'user' AND sender_id != %s) as admin_replies
           FROM support_threads t
           WHERE t.user_id = %s
           ORDER BY t.updated_at DESC""",
        (current_user["id"], current_user["id"]),
    )
    threads = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for t in threads:
        if t.get("created_at"):
            t["created_at"] = t["created_at"].isoformat()
        if t.get("updated_at"):
            t["updated_at"] = t["updated_at"].isoformat()
    return threads


@api.get("/support/{thread_id}")
def get_thread_messages(thread_id: int, current_user=Depends(get_current_user)):
    """User gets messages in their thread."""
    conn = get_conn()
    cur = conn.cursor()
    # Verify ownership (or admin)
    cur.execute("SELECT user_id FROM support_threads WHERE id = %s", (thread_id,))
    thread = cur.fetchone()
    if not thread:
        raise HTTPException(404, "Thread not found")
    if thread["user_id"] != current_user["id"] and not current_user.get("is_admin"):
        raise HTTPException(403, "Not your thread")

    cur.execute(
        """SELECT sm.*, u.name as sender_name, u.avatar_url as sender_avatar
           FROM support_messages sm JOIN users u ON sm.sender_id = u.id
           WHERE sm.thread_id = %s
           ORDER BY sm.created_at ASC""",
        (thread_id,),
    )
    messages = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for m in messages:
        if m.get("created_at"):
            m["created_at"] = m["created_at"].isoformat()
    return messages


@api.post("/support/{thread_id}/reply")
def reply_to_thread(thread_id: int, body: dict, current_user=Depends(get_current_user)):
    """User or admin replies to a thread."""
    message = body.get("message", "").strip()
    if not message:
        raise HTTPException(400, "Message is required")

    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute("SELECT user_id, status FROM support_threads WHERE id = %s", (thread_id,))
        thread = cur.fetchone()
        if not thread:
            raise HTTPException(404, "Thread not found")

        is_admin_user = current_user.get("is_admin", False)
        if thread["user_id"] != current_user["id"] and not is_admin_user:
            raise HTTPException(403, "Not your thread")

        sender_role = "admin" if is_admin_user else "user"

        # Reopen if closed and user replies
        if thread["status"] == "closed" and not is_admin_user:
            cur.execute("UPDATE support_threads SET status = 'open', updated_at = NOW() WHERE id = %s", (thread_id,))
        else:
            cur.execute("UPDATE support_threads SET updated_at = NOW() WHERE id = %s", (thread_id,))

        cur.execute(
            "INSERT INTO support_messages (thread_id, sender_id, sender_role, content) VALUES (%s, %s, %s, %s) RETURNING *",
            (thread_id, current_user["id"], sender_role, message),
        )
        msg = dict(cur.fetchone())
        conn.commit()

        if msg.get("created_at"):
            msg["created_at"] = msg["created_at"].isoformat()
        return msg
    except HTTPException:
        raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()


@api.get("/admin/support")
def admin_list_threads(admin=Depends(require_admin)):
    """Admin sees all support threads."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT t.*, u.name as user_name, u.email as user_email, u.avatar_url as user_avatar,
                  (SELECT content FROM support_messages WHERE thread_id = t.id ORDER BY created_at DESC LIMIT 1) as last_message,
                  (SELECT created_at FROM support_messages WHERE thread_id = t.id ORDER BY created_at DESC LIMIT 1) as last_message_at,
                  (SELECT COUNT(*) FROM support_messages WHERE thread_id = t.id AND sender_role = 'user') as user_messages,
                  (SELECT COUNT(*) FROM support_messages WHERE thread_id = t.id AND sender_role = 'admin') as admin_replies
           FROM support_threads t
           JOIN users u ON t.user_id = u.id
           ORDER BY t.updated_at DESC""",
    )
    threads = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for t in threads:
        for k in ("created_at", "updated_at", "last_message_at"):
            if t.get(k):
                t[k] = t[k].isoformat()
    return threads


@api.post("/admin/support/{thread_id}/close")
def admin_close_thread(thread_id: int, admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("UPDATE support_threads SET status = 'closed', updated_at = NOW() WHERE id = %s", (thread_id,))
    conn.commit()
    cur.close()
    conn.close()
    return {"ok": True}


# ── Sponsor / Donor / Supporter Contact ──────────────────────────────────────

@api.post("/contact/sponsor")
def sponsor_contact(body: dict):
    """Public endpoint — no auth required. For sponsors, donors, supporters."""
    name = body.get("name", "").strip()
    email = body.get("email", "").strip()
    message = body.get("message", "").strip()
    org = body.get("organization", "").strip()
    contact_type = body.get("type", "sponsor")

    if not name or not email or not message:
        raise HTTPException(400, "Name, email, and message are required")
    if contact_type not in ("sponsor", "donor", "supporter", "other"):
        contact_type = "sponsor"

    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO sponsor_contacts (name, email, organization, type, message) VALUES (%s, %s, %s, %s, %s) RETURNING *",
            (name, email, org, contact_type, message),
        )
        row = dict(cur.fetchone())
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()

    if row.get("created_at"):
        row["created_at"] = row["created_at"].isoformat()
    return {"ok": True, "id": row["id"]}


@api.get("/admin/sponsors")
def admin_list_sponsors(admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT sc.*,
                  (SELECT COUNT(*) FROM sponsor_replies WHERE contact_id = sc.id) as reply_count
           FROM sponsor_contacts sc ORDER BY sc.created_at DESC"""
    )
    contacts = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for c in contacts:
        if c.get("created_at"):
            c["created_at"] = c["created_at"].isoformat()
    return contacts


@api.get("/admin/sponsors/{contact_id}/replies")
def admin_get_sponsor_replies(contact_id: int, admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT sr.*, u.name as admin_name
           FROM sponsor_replies sr JOIN users u ON sr.admin_id = u.id
           WHERE sr.contact_id = %s ORDER BY sr.created_at ASC""",
        (contact_id,),
    )
    replies = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for r in replies:
        if r.get("created_at"):
            r["created_at"] = r["created_at"].isoformat()
    return replies


@api.post("/admin/sponsors/{contact_id}/replies")
def admin_reply_sponsor(contact_id: int, body: dict, admin=Depends(require_admin)):
    content = body.get("content", "").strip()
    if not content:
        raise HTTPException(400, "Reply is required")
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "INSERT INTO sponsor_replies (contact_id, admin_id, content) VALUES (%s, %s, %s) RETURNING *",
            (contact_id, admin["id"], content),
        )
        reply = dict(cur.fetchone())
        conn.commit()
    except Exception as e:
        conn.rollback()
        raise HTTPException(500, str(e))
    finally:
        cur.close()
        conn.close()
    if reply.get("created_at"):
        reply["created_at"] = reply["created_at"].isoformat()
    reply["admin_name"] = admin["name"]
    return reply


# ── Tips / Donations ──────────────────────────────────────────────────────────
@api.post("/tips")
def create_tip(body: dict, current_user=Depends(get_current_user)):
    amount = body.get("amount", 0)
    if amount not in (100, 500, 1000):
        raise HTTPException(400, "Invalid tip amount")
    message = body.get("message", "")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO tips (user_id, amount, name, email, message, status) VALUES (%s, %s, %s, %s, %s, 'pending') RETURNING *",
        (current_user["id"], amount, current_user["name"], current_user["email"], message),
    )
    tip = dict(cur.fetchone())
    conn.commit()
    cur.close()
    conn.close()
    if tip.get("created_at"):
        tip["created_at"] = tip["created_at"].isoformat()
    return tip


@api.post("/tips/guest")
def create_guest_tip(body: dict):
    amount = body.get("amount", 0)
    if amount not in (100, 500, 1000):
        raise HTTPException(400, "Invalid tip amount")
    name = body.get("name", "")
    email = body.get("email", "")
    message = body.get("message", "")
    if not email:
        raise HTTPException(400, "Email is required")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO tips (user_id, amount, name, email, message, status) VALUES (NULL, %s, %s, %s, %s, 'pending') RETURNING *",
        (amount, name, email, message),
    )
    tip = dict(cur.fetchone())
    conn.commit()
    cur.close()
    conn.close()
    if tip.get("created_at"):
        tip["created_at"] = tip["created_at"].isoformat()
    return tip


@api.get("/admin/tips")
def admin_list_tips(admin=Depends(require_admin)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM tips ORDER BY created_at DESC")
    tips = [dict(r) for r in cur.fetchall()]
    cur.close()
    conn.close()
    for t in tips:
        if t.get("created_at"):
            t["created_at"] = t["created_at"].isoformat()
    return tips


@api.patch("/admin/tips/{tip_id}")
def admin_update_tip(tip_id: int, body: dict, admin=Depends(require_admin)):
    allowed = {"status"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(400, "No valid fields")
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM tips WHERE id=%s", (tip_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Tip not found")
    set_clause = ", ".join(f"{k} = %s" for k in updates)
    cur.execute(f"UPDATE tips SET {set_clause} WHERE id=%s RETURNING *", list(updates.values()) + [tip_id])
    tip = dict(cur.fetchone())
    conn.commit()
    cur.close()
    conn.close()
    return tip


# ── Bookmarks ──────────────────────────────────────────────────────────────

@api.get("/bookmarks")
def list_bookmarks(current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT b.video_id, v.title, v.image_url, v.thumbnail_url, v.type, v.category, v.created_at, u.name as author_name, u.avatar_url as author_avatar
           FROM bookmarks b
           JOIN videos v ON b.video_id = v.id
           JOIN users u ON v.user_id = u.id
           WHERE b.user_id = %s
           ORDER BY b.created_at DESC""",
        (current_user["id"],),
    )
    result = []
    for r in cur.fetchall():
        item = dict(r)
        if item.get("created_at"):
            item["created_at"] = item["created_at"].isoformat()
        result.append(item)
    cur.close()
    conn.close()
    return result


@api.post("/bookmarks")
def toggle_bookmark(body: dict, current_user=Depends(get_current_user)):
    video_id = body.get("video_id")
    if not video_id:
        raise HTTPException(400, "video_id required")
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT id FROM bookmarks WHERE user_id=%s AND video_id=%s",
            (current_user["id"], video_id),
        )
        existing = cur.fetchone()
        if existing:
            cur.execute("DELETE FROM bookmarks WHERE id=%s", (existing["id"],))
            bookmarked = False
        else:
            cur.execute(
                "INSERT INTO bookmarks (user_id, video_id) VALUES (%s, %s)",
                (current_user["id"], video_id),
            )
            bookmarked = True
        conn.commit()
    finally:
        cur.close()
        conn.close()
    return {"bookmarked": bookmarked}


# ── User Blocks ───────────────────────────────────────────────────────────

@api.get("/blocks")
def list_blocks(current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """SELECT ub.id, ub.blocked_id, u.name as blocked_name, u.avatar_url as blocked_avatar, ub.created_at
           FROM user_blocks ub
           JOIN users u ON ub.blocked_id = u.id
           WHERE ub.blocker_id = %s
           ORDER BY ub.created_at DESC""",
        (current_user["id"],),
    )
    result = []
    for r in cur.fetchall():
        item = dict(r)
        if item.get("created_at"):
            item["created_at"] = item["created_at"].isoformat()
        result.append(item)
    cur.close()
    conn.close()
    return result


@api.post("/blocks")
def toggle_block(body: dict, current_user=Depends(get_current_user)):
    blocked_id = body.get("user_id")
    if not blocked_id:
        raise HTTPException(400, "user_id required")
    if blocked_id == current_user["id"]:
        raise HTTPException(400, "Cannot block yourself")
    conn = get_conn()
    cur = conn.cursor()
    try:
        cur.execute(
            "SELECT id FROM user_blocks WHERE blocker_id=%s AND blocked_id=%s",
            (current_user["id"], blocked_id),
        )
        existing = cur.fetchone()
        if existing:
            cur.execute("DELETE FROM user_blocks WHERE id=%s", (existing["id"],))
            blocked = False
        else:
            cur.execute(
                "INSERT INTO user_blocks (blocker_id, blocked_id) VALUES (%s, %s)",
                (current_user["id"], blocked_id),
            )
            blocked = True
        conn.commit()
    finally:
        cur.close()
        conn.close()
    return {"blocked": blocked}


@api.delete("/blocks/{block_id}")
def remove_block(block_id: int, current_user=Depends(get_current_user)):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM user_blocks WHERE id=%s AND blocker_id=%s", (block_id, current_user["id"]))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "removed"}


def create_app(static_dir: str) -> FastAPI:
    try:
        init_db()
    except Exception as e:
        print(f"[DB] Warning: Could not initialize DB: {e}")

    app = FastAPI()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(api, prefix="/api")

    if os.path.isdir(static_dir):
        assets_dir = os.path.join(static_dir, "assets")
        if os.path.isdir(assets_dir):
            app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

        @app.get("/{path:path}")
        async def spa_fallback(request: Request, path: str):
            file_path = os.path.join(static_dir, path)
            if path and os.path.isfile(file_path):
                return FileResponse(file_path)
            return FileResponse(
                os.path.join(static_dir, "index.html"),
                headers={
                    "Cache-Control": "no-cache, no-store, must-revalidate",
                    "Pragma": "no-cache",
                    "Expires": "0",
                },
            )

    return app
