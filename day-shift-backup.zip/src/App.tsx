import { useState, useEffect, createContext, useContext, useCallback, useRef } from "react";
import type { User, Screen, Match, BeforeInstallPromptEvent } from "./types";
import { initAnalytics, identifyUser, resetUser, trackEvent } from "./lib/analytics";

// ─── Auth Context ─────────────────────────────────────────────────────────────
interface AuthCtx {
  user: User | null;
  token: string | null;
  login: (token: string, user: User) => void;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthCtx>({
  user: null,
  token: null,
  login: () => {},
  logout: () => {},
  refreshUser: async () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

// ─── Nav Context ──────────────────────────────────────────────────────────────
interface NavCtx {
  screen: Screen;
  navigate: (s: Screen, params?: Record<string, unknown>) => void;
  params: Record<string, unknown>;
}

const NavContext = createContext<NavCtx>({
  screen: "feed",
  navigate: () => {},
  params: {},
});

export function useNav() {
  return useContext(NavContext);
}

// ─── Lazy screen imports ──────────────────────────────────────────────────────
import FeedScreen from "./components/FeedScreen";
import PostScreen from "./components/PostScreen";
import MatchesScreen from "./components/MatchesScreen";
import ChatScreen from "./components/ChatScreen";
import ProfileScreen from "./components/ProfileScreen";
import AuthScreen from "./components/AuthScreen";
import UserProfileScreen from "./components/UserProfileScreen";
import ReviewScreen from "./components/ReviewScreen";
import AdminScreen from "./components/AdminScreen";
import SupportScreen from "./components/SupportScreen";
import SponsorScreen from "./components/SponsorScreen";
import LegalScreen from "./components/LegalScreen";
import OnboardingScreen from "./components/OnboardingScreen";
import AboutScreen from "./components/AboutScreen";

// Icons (inline SVG to avoid lucide overhead in nav)
import {
  Play,
  Plus,
  MessageCircle,
  User as UserIcon,
  LogIn,
  Shield,
  Heart,
  Download,
  X,
  Bell,
} from "lucide-react";

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [screen, setScreen] = useState<Screen>("feed");
  const [params, setParams] = useState<Record<string, unknown>>({});
  const [pendingMatches, setPendingMatches] = useState(0);
  const [hydrated, setHydrated] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [dismissInstall, setDismissInstall] = useState(false);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>("default");

  // PWA install prompt
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    setInstallPrompt(null);
    setDismissInstall(true);
  };

  // Request notification permission
  const requestNotifs = async () => {
    if (!("Notification" in window)) return;
    const perm = await Notification.requestPermission();
    setNotifPermission(perm);
  };

  // Send a browser notification
  const sendNotification = (title: string, body: string) => {
    if (notifPermission !== "granted") return;
    try {
      new Notification(title, { body, icon: "/icons/icon-192x192.png", badge: "/icons/icon-72x72.png" });
    } catch {}
  };

  // Track previous match/message count to detect new ones
  const prevPendingRef = useRef(0);

  // Check notification support on mount
  useEffect(() => {
    if ("Notification" in window) {
      setNotifPermission(Notification.permission);
    }
  }, []);
  // Rehydrate from localStorage and handle deep links
  useEffect(() => {
    const stored = localStorage.getItem("ds_token");
    const storedUser = localStorage.getItem("ds_user");
    if (stored && storedUser) {
      setToken(stored);
      setUser(JSON.parse(storedUser));
    }
    
    const params = new URLSearchParams(window.location.search);
    const screenParam = params.get("screen");
    if (screenParam === "reset" && params.get("token")) {
      setScreen("reset");
      setParams({ token: params.get("token") });
      // clear the URL so reloading doesn't get stuck
      window.history.replaceState({}, document.title, "/");
    } else if (screenParam === "about") {
      setScreen("about");
      window.history.replaceState({}, document.title, "/");
    } else if (screenParam) {
      setScreen(screenParam as Screen);
      window.history.replaceState({}, document.title, "/");
    }
    
    setHydrated(true);
    initAnalytics();
  }, []);

  const login = useCallback((tok: string, u: User) => {
    setToken(tok);
    setUser(u);
    localStorage.setItem("ds_token", tok);
    localStorage.setItem("ds_user", JSON.stringify(u));
    identifyUser(u.id, { name: u.name, role: u.role, email: u.email });
    trackEvent("user_login", { role: u.role });
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("ds_token");
    localStorage.removeItem("ds_user");
    trackEvent("user_logout");
    resetUser();
    setScreen("feed");
  }, []);

  const refreshUser = useCallback(async () => {
    const tok = localStorage.getItem("ds_token");
    if (!tok) return;
    try {
      const res = await fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${tok}` },
      });
      if (res.ok) {
        const u = await res.json();
        setUser(u);
        localStorage.setItem("ds_user", JSON.stringify(u));
        identifyUser(u.id, { name: u.name, role: u.role, email: u.email });
      } else if (res.status === 403) {
        // Account suspended — force logout
        setToken(null);
        setUser(null);
        localStorage.removeItem("ds_token");
        localStorage.removeItem("ds_user");
      }
    } catch {}
  }, []);

  // Refresh user data from server after hydration (picks up is_admin, etc.)
  useEffect(() => {
    if (hydrated && token) refreshUser();
  }, [hydrated, token, refreshUser]);

  // Redirect to onboarding for new users who haven't completed it
  useEffect(() => {
    if (user && token && !user.onboarded && screen !== "onboarding") {
      setScreen("onboarding");
    }
  }, [user, token, screen]);

  // Navigation history stack for browser back button support
  const historyRef = useRef<Array<{ screen: Screen; params: Record<string, unknown> }>>([]);
  const screenRef = useRef(screen);
  const paramsRef = useRef(params);
  screenRef.current = screen;
  paramsRef.current = params;

  const navigate = useCallback((s: Screen, p: Record<string, unknown> = {}) => {
    // Save current screen to history before navigating away
    historyRef.current.push({ screen: screenRef.current, params: paramsRef.current });
    setScreen(s);
    setParams(p);
    window.scrollTo(0, 0);
    // Push to browser history so phone back button works
    window.history.pushState({ screen: s, params: p }, "");
  }, []);

  // Intercept browser back button for in-app navigation
  useEffect(() => {
    // Seed initial history entry
    window.history.replaceState({ screen, params }, "");
    const handlePop = () => {
      // Pop from our history stack — go to previous screen
      const prev = historyRef.current.pop();
      if (prev) {
        setScreen(prev.screen);
        setParams(prev.params);
      } else {
        // No history left — go to feed
        setScreen("feed");
        setParams({});
      }
      window.scrollTo(0, 0);
    };
    window.addEventListener("popstate", handlePop);
    return () => window.removeEventListener("popstate", handlePop);
  }, []);

  // Poll pending matches count
  useEffect(() => {
    if (!token) return;
    const fetchPending = async () => {
      try {
        const res = await fetch("/api/matches", {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data: Match[] = await res.json();
          const count = data.filter((m) => m.status === "pending" && m.initiated_by !== user?.id).length;
          setPendingMatches(count);
          // Notify on new match
          if (count > prevPendingRef.current && prevPendingRef.current > 0) {
            sendNotification("New Match!", `Someone wants to connect with you on Day Shift`);
          }
          prevPendingRef.current = count;
        }
      } catch {}
    };
    fetchPending();
    const id = setInterval(fetchPending, 30_000);
    return () => clearInterval(id);
  }, [token, screen]);

  if (!hydrated) {
    return (
      <div className="h-screen bg-background flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const authCtx: AuthCtx = { user, token, login, logout, refreshUser };
  const navCtx: NavCtx = { screen, navigate, params };

  return (
    <AuthContext.Provider value={authCtx}>
      <NavContext.Provider value={navCtx}>
        <div className="h-screen overflow-hidden bg-background flex flex-col max-w-[430px] md:max-w-[768px] mx-auto relative shadow-2xl md:shadow-none border-x border-border/50">
          {/* Header — hidden on about screen */}
          {screen !== "about" && (
          <header className="flex-shrink-0 z-50 bg-background/90 backdrop-blur-md border-b border-border px-4 md:px-6 py-3 flex items-center justify-between">
            <button
              onClick={() => navigate("feed")}
              className="flex items-center gap-2"
            >
              <img src="/dayshift-logo.png" alt="Day Shift" className="h-8 w-auto md:h-10" />
            </button>

            {user ? (
              <div className="flex items-center gap-2">
                {user.is_admin && (
                  <button
                    onClick={() => navigate("admin")}
                    className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${screen === "admin" ? "bg-primary text-primary-foreground" : "bg-primary/10 text-primary hover:bg-primary/20"}`}
                    title="Admin Dashboard"
                  >
                    <Shield size={16} />
                  </button>
                )}
                {!user.is_admin && (
                  <span className="text-xs text-muted-foreground">
                    {user.role === "worker" ? "👷" : "🏢"} {user.name.split(" ")[0]}
                  </span>
                )}
                {/* Notification bell */}
                <button
                  onClick={notifPermission === "default" ? requestNotifs : () => navigate("matches")}
                  className={`w-9 h-9 rounded-full flex items-center justify-center transition-colors ${
                    pendingMatches > 0
                      ? "bg-primary text-primary-foreground"
                      : "bg-secondary/50 text-muted-foreground hover:text-foreground"
                  }`}
                  title="Notifications"
                >
                  <Bell size={16} />
                  {pendingMatches > 0 && (
                    <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-red-500 text-white rounded-full text-[8px] flex items-center justify-center font-bold">
                      {pendingMatches > 9 ? "9+" : pendingMatches}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => navigate("profile")}
                  className="w-9 h-9 rounded-full bg-secondary border border-border overflow-hidden"
                >
                  {user.avatar_url ? (
                    <img src={user.avatar_url} alt="" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-xs font-semibold text-primary">
                      {user.name[0]?.toUpperCase()}
                    </div>
                  )}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => navigate("sponsor")}
                  className="flex items-center gap-1 text-xs text-primary/80 font-medium hover:text-primary transition-colors"
                >
                  <Heart size={15} /> Support Us
                </button>
                <button
                  onClick={() => navigate("login")}
                  className="flex items-center gap-1.5 text-sm text-primary font-medium"
                >
                  <LogIn size={17} /> Sign In
                </button>
              </div>
            )}
          </header>
          )}

          {/* PWA Install Banner — hidden on about screen */}
          {screen !== "about" && installPrompt && !dismissInstall && (
            <div className="flex-shrink-0 px-3 py-2 bg-primary/10 border-b border-primary/20 flex items-center gap-2">
              <Download size={18} className="text-primary flex-shrink-0" />
              <span className="text-xs text-primary flex-1 font-medium">Install Day Shift app</span>
              <button
                onClick={handleInstall}
                className="px-3 py-1 bg-primary text-primary-foreground rounded-full text-[11px] font-semibold hover:bg-primary/90 transition-colors"
              >
                Install
              </button>
              <button
                onClick={() => setDismissInstall(true)}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                <X size={16} />
              </button>
            </div>
          )}

          {/* Screen content */}
          <main className={`flex-1 min-h-0 flex flex-col ${["login","register","forgot","reset","about"].includes(screen) ? "overflow-y-auto" : "overflow-hidden"}`}>
            {screen === "feed" && <FeedScreen />}
            {screen === "post" && <PostScreen />}
            {screen === "matches" && <MatchesScreen />}
            {screen === "chat" && <ChatScreen matchId={params.matchId as number} />}
            {screen === "profile" && <ProfileScreen />}
            {screen === "login" && <AuthScreen mode="login" />}
            {screen === "register" && <AuthScreen mode="register" />}
            {screen === "forgot" && <AuthScreen mode="forgot" />}
            {screen === "reset" && <AuthScreen mode="reset" tokenParam={params.token as string} />}
            {screen === "user-profile" && <UserProfileScreen userId={params.userId as number} />}
            {screen === "review" && (
              <ReviewScreen
                matchId={params.matchId as number}
                revieweeId={params.revieweeId as number}
                revieweeName={params.revieweeName as string}
              />
            )}
            {screen === "admin" && <AdminScreen />}
            {screen === "support" && <SupportScreen />}
            {screen === "sponsor" && <SponsorScreen />}
            {screen === "terms" && <LegalScreen type="terms" />}
            {screen === "privacy" && <LegalScreen type="privacy" />}
            {screen === "onboarding" && <OnboardingScreen />}
            {screen === "about" && <AboutScreen />}
          </main>

          {/* Bottom Nav — hidden on auth/about screens */}
          {!["login", "register", "forgot", "reset", "about"].includes(screen) && (
          <nav className="flex-shrink-0 z-50 bg-background/95 backdrop-blur-md border-t border-border">
            <div className="flex items-stretch">
              <NavBtn
                icon={<Play size={20} />}
                label="Feed"
                active={screen === "feed"}
                onClick={() => navigate("feed")}
              />
              {user && (
                <NavBtn
                  icon={<Plus size={20} />}
                  label="Post"
                  active={screen === "post"}
                  highlight
                  onClick={() => navigate("post")}
                />
              )}
              <NavBtn
                icon={
                  <div className="relative">
                    <MessageCircle size={20} />
                    {pendingMatches > 0 && (
                      <span className="absolute -top-1 -right-1 w-4 h-4 bg-primary text-primary-foreground rounded-full text-[9px] flex items-center justify-center font-bold">
                        {pendingMatches}
                      </span>
                    )}
                  </div>
                }
                label="Matches"
                active={screen === "matches"}
                onClick={() => {
                  if (!user) navigate("login");
                  else navigate("matches");
                }}
              />
              <NavBtn
                icon={<UserIcon size={20} />}
                label={user ? "Profile" : "Login"}
                active={screen === "profile" || screen === "login" || screen === "register"}
                onClick={() => {
                  if (!user) navigate("login");
                  else navigate("profile");
                }}
              />
            </div>
          </nav>
          )}
        </div>
      </NavContext.Provider>
    </AuthContext.Provider>
  );
}

function NavBtn({
  icon,
  label,
  active,
  highlight,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  active: boolean;
  highlight?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 flex flex-col items-center justify-center py-2 gap-0.5 transition-colors
        ${active ? "text-primary" : "text-muted-foreground"}
        ${highlight
          ? "relative"
          : ""
        }`}
    >
      {highlight ? (
        <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center ember-glow -mt-5 mb-0.5 shadow-lg">
          <span className="text-primary-foreground">{icon}</span>
        </div>
      ) : (
        icon
      )}
      <span className={`text-[10px] font-medium ${active && !highlight ? "nav-active" : ""}`}>
        {label}
      </span>
    </button>
  );
}
