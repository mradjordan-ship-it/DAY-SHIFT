import { useState } from "react";
import { useNav, useAuth } from "../App";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, Heart, Send, CheckCircle2, HandHeart, DollarSign, ExternalLink } from "lucide-react";

const TYPES = [
  { value: "sponsor", label: "Sponsor", desc: "Partner with us to reach hospitality workers", icon: "🤝" },
  { value: "donor", label: "Donor", desc: "Support our mission with a contribution", icon: "💚" },
  { value: "supporter", label: "Supporter", desc: "Cheer us on and spread the word", icon: "📣" },
  { value: "other", label: "Other", desc: "Something else on your mind", icon: "✉️" },
] as const;

export default function SponsorScreen() {
  const { navigate } = useNav();
  const { user, token } = useAuth();
  const [contactType, setContactType] = useState<string>("sponsor");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [org, setOrg] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [tipAmount, setTipAmount] = useState<number>(0);
  const [tipMessage, setTipMessage] = useState("");
  const [tipSending, setTipSending] = useState(false);
  const [tipSent, setTipSent] = useState(false);
  const cashappUrl = "https://cash.app/$InvitoChef";

  const handleSubmit = async () => {
    if (!name.trim() || !email.trim() || !message.trim()) return;
    setSending(true);
    try {
      const res = await fetch("/api/contact/sponsor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, organization: org, type: contactType, message }),
      });
      if (res.ok) setSent(true);
    } finally {
      setSending(false);
    }
  };

  const handleTip = async () => {
    if (!tipAmount) return;
    setTipSending(true);
    try {
      const endpoint = user ? "/api/tips" : "/api/tips/guest";
      const body: Record<string, unknown> = { amount: tipAmount, message: tipMessage };
      if (!user) {
        body.name = name;
        body.email = email;
        if (!email) return;
      }
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (token) headers["Authorization"] = `Bearer ${token}`;
      const res = await fetch(endpoint, {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      });
      if (res.ok) setTipSent(true);
    } finally {
      setTipSending(false);
    }
  };

  if (sent) {
    return (
      <div className="overflow-y-auto h-[calc(100vh-120px)] pb-6">
        <div className="flex flex-col items-center justify-center py-12 px-6 text-center">
          <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mb-4 ember-glow">
            <CheckCircle2 size={32} className="text-primary" />
          </div>
          <h2 className="text-3xl text-foreground mb-2" style={{ fontFamily: "'Bebas Neue'" }}>
            Message Sent!
          </h2>
          <p className="text-muted-foreground text-xs mb-6 max-w-xs leading-relaxed">
            Thank you for reaching out! Your inquiry/request has been sent directly to the Admin.
          </p>

          {/* Prompt to pay via Cash App right away */}
          <div className="bg-gradient-to-br from-green-500/10 to-green-900/10 border border-green-500/20 rounded-2xl p-5 mb-8 w-full max-w-sm text-center">
            <p className="text-white font-semibold text-xs mb-3 leading-relaxed">
              Complete your sponsorship, donation, or purchase via Cash App:
            </p>
            <Button asChild className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold">
              <a href={cashappUrl} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-2">
                <ExternalLink size={16} /> Pay with Cash App
              </a>
            </Button>
          </div>

          <Button onClick={() => navigate("feed")} className="bg-primary text-primary-foreground ember-glow">
            Back to Feed
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-y-auto h-[calc(100vh-120px)] pb-6">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-border">
        <button
          onClick={() => navigate("feed")}
          className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center"
        >
          <ArrowLeft size={16} />
        </button>
        <div className="flex-1">
          <h2 className="text-2xl text-foreground" style={{ fontFamily: "'Bebas Neue'" }}>
            Support Day Shift
          </h2>
          <p className="text-muted-foreground text-xs">Partnership, donations & community support</p>
        </div>
        <HandHeart size={20} className="text-primary" />
      </div>

      <div className="p-5 space-y-5">
        {/* Tip Jar */}
        {tipSent ? (
          <div className="bg-card border border-amber-500/30 rounded-2xl p-6 text-center">
            <div className="w-14 h-14 bg-amber-500/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 size={28} className="text-amber-400" />
            </div>
            <h3 className="text-xl text-foreground" style={{ fontFamily: "'Bebas Neue'" }}>Thank You!</h3>
            <p className="text-muted-foreground text-xs mt-1">Your tip means the world to us 💛</p>
          </div>
        ) : (
          <div className="bg-gradient-to-br from-amber-500/10 to-amber-900/10 border border-amber-500/20 rounded-2xl p-4 space-y-3">
            <div className="flex items-center gap-2">
              <DollarSign size={18} className="text-amber-400" />
              <h3 className="text-lg text-foreground" style={{ fontFamily: "'Bebas Neue'" }}>Tip Jar</h3>
            </div>
            <p className="text-muted-foreground text-xs leading-relaxed">
              Day Shift is community-supported! Sponsoring, donating, supporting, or making a purchase? Tap below ☕
            </p>
            <Button asChild className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold">
              <a href={cashappUrl} target="_blank" rel="noreferrer" className="inline-flex items-center justify-center gap-2">
                <ExternalLink size={16} /> Cash App
              </a>
            </Button>
            <div className="flex gap-2">
              {[
                { cents: 100, label: "$1" },
                { cents: 500, label: "$5" },
                { cents: 1000, label: "$10" },
              ].map((t) => (
                <button
                  key={t.cents}
                  onClick={() => setTipAmount(t.cents)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all border ${
                    tipAmount === t.cents
                      ? "bg-amber-500 text-black border-amber-400"
                      : "bg-secondary text-muted-foreground border-border hover:bg-muted"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
            {tipAmount > 0 && (
              <>
                {!user && (
                  <div className="space-y-1 mb-2">
                    <Input
                      placeholder="Your email *"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-secondary border-border text-xs h-8"
                    />
                  </div>
                )}
                <Textarea
                  placeholder="Leave a note (optional)"
                  value={tipMessage}
                  onChange={(e) => setTipMessage(e.target.value)}
                  rows={2}
                  className="bg-secondary border-border text-xs resize-none mb-2"
                />
                <Button
                  onClick={handleTip}
                  disabled={tipSending || (!user && !email.trim())}
                  className="w-full bg-amber-500 hover:bg-amber-600 text-black font-semibold"
                >
                  {tipSending ? "Processing…" : `Tip $${tipAmount / 100}`}
                </Button>
              </>
            )}
          </div>
        )}

        {/* Type selector */}
        <div>
          <Label className="text-xs uppercase tracking-wider text-muted-foreground mb-2 block">I am a…</Label>
          <div className="grid grid-cols-2 gap-2">
            {TYPES.map((t) => (
              <button
                key={t.value}
                onClick={() => setContactType(t.value)}
                className={`flex flex-col items-center gap-1 py-3 rounded-xl text-xs font-medium transition-all border ${
                  contactType === t.value
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-secondary text-muted-foreground border-border hover:bg-muted"
                }`}
              >
                <span className="text-lg">{t.icon}</span>
                <span className="font-semibold">{t.label}</span>
                <span className={`text-[9px] ${contactType === t.value ? "text-primary-foreground/70" : "opacity-60"}`}>
                  {t.desc}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Form fields */}
        <div className="space-y-3">
          <div className="space-y-1">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Name *</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your full name"
              className="bg-secondary border-border"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Email *</Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="bg-secondary border-border"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Organization</Label>
            <Input
              value={org}
              onChange={(e) => setOrg(e.target.value)}
              placeholder="Company or org name (optional)"
              className="bg-secondary border-border"
            />
          </div>
          <div className="space-y-1">
            <Label className="text-xs uppercase tracking-wider text-muted-foreground">Message *</Label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Tell us about your interest in Day Shift…"
              rows={5}
              className="bg-secondary border-border resize-none"
            />
          </div>
        </div>

        <Button
          onClick={handleSubmit}
          disabled={!name.trim() || !email.trim() || !message.trim() || sending}
          className="w-full bg-primary text-primary-foreground ember-glow"
        >
          {sending ? (
            <span className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin" />
              Sending…
            </span>
          ) : (
            <span className="flex items-center gap-2">
              <Send size={16} /> Send Message
            </span>
          )}
        </Button>

        <p className="text-center text-muted-foreground/60 text-[10px]">
          No account needed · We typically respond within 48 hours
        </p>
      </div>
    </div>
  );
}
