import { useNav } from "../App";

export default function LegalScreen({ type }: { type: "terms" | "privacy" }) {
  const { navigate } = useNav();

  return (
    <div className="overflow-y-auto h-[calc(100vh-120px)] pb-6">
      {/* Header */}
      <div className="px-4 pt-4 pb-3 border-b border-border flex items-center gap-3">
        <button
          onClick={() => navigate("feed")}
          className="text-muted-foreground hover:text-foreground transition-colors text-sm"
        >
          ← Back
        </button>
        <h1 className="text-lg font-bold text-foreground">
          {type === "terms" ? "Terms of Use" : "Privacy Policy"}
        </h1>
      </div>

      <div className="px-4 py-4 space-y-4">
        {type === "terms" ? <TermsContent /> : <PrivacyContent />}
      </div>

      <div className="px-4 pt-2 pb-4">
        <p className="text-xs text-muted-foreground text-center">
          Last updated: June 1, 2026
        </p>
      </div>
    </div>
  );
}

function TermsContent() {
  const { navigate } = useNav();

  return (
    <div className="space-y-4 text-sm text-muted-foreground leading-relaxed">
      <Section title="1. Acceptance of Terms">
        By creating an account or using Day Shift, you agree to be bound by these Terms of Use. If you do not agree, do not use the app.
      </Section>

      <Section title="2. Description of Service">
        Day Shift is a platform that connects culinary workers ("Crew") with kitchens and food service establishments ("Kitchens") for shift-based work opportunities. Day Shift acts solely as a matching platform and does not employ Crew members, guarantee shifts, or act as a staffing agency.
      </Section>

      <Section title="3. Disclaimer of Liability">
        Day Shift is a matching platform only. We are not liable for pay, compensation, rides, transportation, injuries, disputes, property damage, or any outcomes that occur before, during, or after Crew and Kitchens connect through the app. All employment relationships, wages, working conditions, and agreements are solely between Crew and Kitchens. You assume all responsibility for your interactions and work arrangements.
      </Section>

      <Section title="4. User Conduct">
        You agree to:
        <ul className="list-disc list-inside mt-1 space-y-1">
          <li>Provide accurate information in your profile</li>
          <li>Not misrepresent your skills, experience, or qualifications</li>
          <li>Not use the platform for harassment, discrimination, or illegal activities</li>
          <li>Not post content that is false, misleading, or harmful</li>
          <li>Comply with all applicable local, state, and federal labor laws</li>
        </ul>
      </Section>

      <Section title="5. Content & Postings">
        You retain ownership of content you post. By posting, you grant Day Shift a limited license to display your content within the app. You are responsible for ensuring you have the right to post any content (images, videos, text).
      </Section>

      <Section title="6. Advertiser & Sponsored Content">
        Sponsored posts and advertiser content are clearly marked. Day Shift does not endorse or guarantee the quality of advertised products, services, or shifts. You are responsible for evaluating any sponsored offerings independently.
      </Section>

      <Section title="7. Account Termination">
        We reserve the right to suspend or terminate accounts that violate these terms. You may delete your account at any time through the app settings. Upon deletion, your personal data will be removed in accordance with our Privacy Policy.
      </Section>

      <Section title="8. Changes to Terms">
        We may update these Terms from time to time. Continued use of the app after changes constitutes acceptance of the updated Terms. We will notify users of material changes.
      </Section>

      <Section title="9. Contact">
        For questions about these Terms, visit our{" "}
        <button onClick={() => navigate("support")} className="text-primary underline">Support page</button>.
      </Section>
    </div>
  );
}

function PrivacyContent() {
  const { navigate } = useNav();

  return (
    <div className="space-y-4 text-sm text-muted-foreground leading-relaxed">
      <Section title="1. Information We Collect">
        <ul className="list-disc list-inside mt-1 space-y-1">
          <li><strong>Account info:</strong> name, email, profile photo</li>
          <li><strong>Profile data:</strong> role (worker/employer), skills, cuisine type, pay rate, experience, location</li>
          <li><strong>Content:</strong> posts, images, videos, messages you create</li>
          <li><strong>Usage data:</strong> interactions, matches, likes, app activity</li>
          <li><strong>Device data:</strong> device type, browser, for app optimization</li>
        </ul>
      </Section>

      <Section title="2. How We Use Your Information">
        We use your information to:
        <ul className="list-disc list-inside mt-1 space-y-1">
          <li>Provide and operate the matching platform</li>
          <li>Connect Crew with Kitchens based on preferences</li>
          <li>Enable messaging between matched users</li>
          <li>Improve the app and user experience</li>
          <li>Send service-related communications (with your consent for marketing)</li>
          <li>Ensure safety and prevent fraud</li>
        </ul>
      </Section>

      <Section title="3. Data Sharing">
        We do not sell your personal data. We may share data with:
        <ul className="list-disc list-inside mt-1 space-y-1">
          <li>Other users — your profile is visible to the Day Shift community</li>
          <li>Service providers — for hosting, analytics, and app functionality</li>
          <li>When required by law</li>
        </ul>
      </Section>

      <Section title="4. Data Security">
        We implement industry-standard security measures to protect your data. However, no method of transmission or storage is 100% secure. You are responsible for keeping your password confidential.
      </Section>

      <Section title="5. Your Rights">
        You have the right to:
        <ul className="list-disc list-inside mt-1 space-y-1">
          <li>Access and download your personal data</li>
          <li>Correct inaccurate information</li>
          <li>Delete your account and associated data</li>
          <li>Opt out of marketing communications</li>
        </ul>
      </Section>

      <Section title="6. Data Retention">
        If you delete your account, your personal data will be removed within 30 days. Anonymized usage data may be retained for analytics purposes.
      </Section>

      <Section title="7. Cookies & Tracking">
        We may use cookies and similar technologies for app functionality and analytics. No third-party advertising cookies are used.
      </Section>

      <Section title="8. Children's Privacy">
        Day Shift is not intended for users under 18. We do not knowingly collect data from minors.
      </Section>

      <Section title="9. Contact">
        For privacy inquiries or data requests, visit our{" "}
        <button onClick={() => navigate("support")} className="text-primary underline">Support page</button>.
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-sm font-semibold text-foreground mb-1.5">{title}</h2>
      <div>{children}</div>
    </div>
  );
}
