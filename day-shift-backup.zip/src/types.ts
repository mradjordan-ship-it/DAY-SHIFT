// PWA install prompt type (not in standard TS libs)
export interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export type ApiStatus = "checking" | "connected" | "error";

export interface HealthResponse {
  ok: boolean;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: "worker" | "employer";
  is_admin: boolean;
  is_advertiser: boolean;
  advertiser_agreement_accepted: boolean;
  onboarded: boolean;
  bio: string;
  avatar_url: string;
  avg_rating: number;
  total_shifts: number;
  created_at: string;
}

export interface Video {
  id: number;
  user_id: number;
  video_url: string | null;
  image_url: string | null;
  thumbnail_url: string;
  type: "worker" | "employer";
  post_type: "video" | "image" | "text";
  category: "general" | "sale" | "event";
  price: string;
  event_date: string;
  event_time: string;
  aspect_ratio: "9:16" | "1:1" | "4:5" | "16:9";
  title: string | null;
  description: string;
  cuisine_type: string;
  pay_rate: string;
  hours: string;
  experience_level: string;
  location: string;
  likes: number;
  scheduled_at: string | null;
  created_at: string;
  author_name: string;
  author_avatar: string;
  author_rating: number;
  author_role: string;
  author_is_admin: boolean;
  author_is_advertiser: boolean;
  liked_by_me: boolean;
}

export interface Match {
  id: number;
  worker_id: number;
  employer_id: number;
  worker_video_id: number;
  employer_video_id: number;
  status: "pending" | "active" | "completed" | "cancelled";
  initiated_by: number;
  worker_confirmed: boolean;
  employer_confirmed: boolean;
  created_at: string;
  worker_name: string;
  worker_avatar: string;
  employer_name: string;
  employer_avatar: string;
  employer_location?: string;
}

export interface Message {
  id: number;
  match_id: number;
  sender_id: number;
  content: string;
  created_at: string;
  sender_name: string;
  sender_avatar: string;
}

export interface Review {
  id: number;
  match_id: number;
  reviewer_id: number;
  reviewee_id: number;
  rating: number;
  feedback: string;
  created_at: string;
  reviewer_name: string;
  reviewer_avatar: string;
}

export type Screen =
  | "feed"
  | "post"
  | "matches"
  | "chat"
  | "profile"
  | "login"
  | "register"
  | "forgot"
  | "reset"
  | "user-profile"
  | "review"
  | "admin"
  | "support"
  | "sponsor"
  | "terms"
  | "privacy"
  | "onboarding"
  | "about";

export type FeedTab = "all" | "workers" | "employers";
